﻿//Este programa trata de una calculadora simple para ejecutar en la consola.
Console.WriteLine("Bienvenidos a la Calculadora. Esta calculadora solo ejecuta operaciones" +
    " simples de suma, resta, multiplicación y división");
Console.WriteLine("Elige la operación a realizar usando su operador");

char operador;
double num1, num2, result = 0;

//Solicitamos el operador por consola
Console.Write("Introduce el operador: ");
operador = Console.ReadKey().KeyChar;

//Solicitamos los dos operandos por consola
Console.Write("\nIntroduce el primer número: ");
//Uso tryparse para convertir las strings en doubles
if (double.TryParse(Console.ReadLine(), out num1)) {
    Console.Write("Introduce el segundo número: ");
    if (double.TryParse(Console.ReadLine(), out num2)) {
        //Uso un switch para cada operador diferente
        switch (operador) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                if (num2 != 0) {
                    result = num1 / num2;
                }
                //Recogemos los posibles errores, distintas operaciones no realizables
                //como dividir entre 0
                else {
                    Console.WriteLine("\nError: No se puede dividir entre cero.");
                    Environment.Exit(1);
                }
                break;
            default:
                Console.WriteLine("\nError: Operación no válida.");
                Environment.Exit(1);
                break;
        }

        //Mostramos el resultado usando el símbolo $ y las {} por rápidez.
        Console.WriteLine($"\nEl resultado es: {result}");
    }
    else
    {
        Console.WriteLine("\nError: El segundo número introducido no es válido.");
        Environment.Exit(1);
    }
}
else
{
    Console.WriteLine("\nError: El primer número introducido no es válido.");
    Environment.Exit(1);
}

    
